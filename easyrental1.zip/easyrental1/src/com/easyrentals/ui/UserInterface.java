package com.easyrentals.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.easyrentals.customer.Customer;
import com.easyrentals.model.Bike;
import com.easyrentals.service.BikeService;

public class UserInterface {

	public UserInterface() {
		super();

	}

	public static void main(String[] args) {

		Customer c1 = new Customer(1001, "pavan", LocalDate.of(1971, 3, 16), "P", "Male", "9543206543",
				"pavan@gmail.com", LocalDate.of(1999, 10, 2), "USA");

		Customer c2 = new Customer(1002, "ramyani", LocalDate.of(1980, 3, 15), "P", "Female", "9019996544",
				"ramayani@gmail.com", LocalDate.of(1956, 10, 2), "China");

		Customer c4 = new Customer(1004, "rahul", LocalDate.of(1979, 3, 13), "P", "male", "961234543",
				"rahul@gmail.com", LocalDate.of(1999, 10, 5), "France");

		Customer c5 = new Customer(1005, "Mohit", LocalDate.of(1999, 04, 7), "P", "Male", "998778754",
				"mohit@gmail.com", LocalDate.of(2000, 1, 1), "Spain");

		List<Customer> ld = new ArrayList<>();
		ld.add(c1);
		ld.add(c2);
		ld.add(c4);
		ld.add(c5);

		Customer.detailsCheck(ld, "Asia/Kolkata");

		BikeService service = new BikeService();
		Set<Bike> bikes = service.getBikeDetails();
		bikes.forEach(bike -> {
			System.out.println("bike id:" + bike.getBikeId() + "\nBike Name:" + bike.getBikeName() + "\nCompany Name:"
					+ bike.getCompanyName() + "\nBike Serial No:" + bike.getSerialNumber() + "\nRent Prize:"
					+ bike.getRentPrice());

			System.out.println("--------------------------------");
		});
	}

}
