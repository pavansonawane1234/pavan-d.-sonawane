package com.easyrentals.dao;

import java.util.LinkedHashSet;
import java.util.Set;

import com.easyrentals.model.Bike;

public class DataUtil {
	Set<Bike> bikes = new LinkedHashSet<>();

	public DataUtil() {

		Bike bike1 = new Bike();
		bike1.setBikeId(1001);
		bike1.setBikeName("CBR");
		bike1.setCompanyName("Honda");
		bike1.setSerialNumber("Hon:1001");
		bike1.setRentPrice(500.00);
		bikes.add(bike1);

		Bike bike2 = new Bike();
		bike2.setBikeId(1002);
		bike2.setBikeName("CBZ");
		bike2.setCompanyName("Hero");
		bike2.setSerialNumber("Her:1002");
		bike2.setRentPrice(800.0);
		bikes.add(bike2);

		Bike bike3 = new Bike();
		bike3.setBikeId(1003);
		bike3.setBikeName("Bullet");
		bike3.setCompanyName("Enfield");
		bike3.setSerialNumber("Enf:1003");
		bike3.setRentPrice(900.0);
		bikes.add(bike3);

		Bike bike4 = new Bike();
		bike4.setBikeId(1004);
		bike4.setBikeName("Karizma");
		bike4.setCompanyName("Hero");
		bike4.setSerialNumber("Her:1004");
		bike4.setRentPrice(700.0);
		bikes.add(bike4);
	}

	public Set<Bike> getBikeDetails() {
		return bikes;

	}
}
