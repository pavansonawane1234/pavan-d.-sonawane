package com.easyrentals.service;

import java.util.Set;

import com.easyrentals.dao.DataUtil;
import com.easyrentals.model.Bike;

public class BikeService {

	public Set<Bike> getBikeDetails() {
		DataUtil data = new DataUtil();
		return data.getBikeDetails();
	}
}
