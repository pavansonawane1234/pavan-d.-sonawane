package com.easyrentals.customer;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

public class Customer {

	public int id;
	public String name;
	private LocalDate dob;
	private String custType; // P -> Privileged, R-> Regular
	private String gender;
	private String contactNo;
	private String emailId;
	private LocalDate registrationDate;
	private String country;

	public Customer(int id, String name, LocalDate dob, String custType, String gender, String contactNo,
			String emailId, LocalDate registrationDate, String country) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.custType = custType;
		this.gender = gender;
		this.contactNo = contactNo;
		this.emailId = emailId;
		this.registrationDate = registrationDate;
		this.country = country;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public double calculateRentalPrice() {
		return 0.0;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", dob=" + dob + ", custType=" + custType + ", gender="
				+ gender + ", contactNo=" + contactNo + ", emailId=" + emailId + ", registrationDate="
				+ registrationDate + ", country=" + country + "]";
	}

	public static void detailsCheck(List<Customer> customers, String timeZone) {
		System.out.println("----Requirement based on asendending order DOB----");
		List<Customer> sortedList = customers.stream().sorted((c1, c2) -> c1.getDob().compareTo(c2.getDob())).toList();
		Details(sortedList);
		System.out.println();
		System.out.println("--------Discount----------");
		for (Customer customer : sortedList) {
			if (customer.getCountry().matches("(USA|Spain|Germany|France|China)")) {
				if ((LocalDate.now().getYear() - customer.getRegistrationDate().getYear()) >= 5) {
					System.out.println(customer.name + "! You got discount of 10%");
				}
			} else {
				System.out.println("Invalid Country code!!");
			}
		}
		System.out.println();

		List<Customer> regularCustomers = sortedList.stream()
				.filter(customer1 -> ((customer1.getCustType().equals("R")) && (customer1.getCountry().equals("China"))
						&& (LocalDate.now().getYear()) - customer1.getDob().getYear() > 18))
				.toList();
		long count = sortedList.stream()
				.filter(customer2 -> (LocalDate.now().getYear() - customer2.getDob().getYear() >= 50)).count();

		List<Customer> priviledgedCustomers = sortedList.stream()
				.filter(customer3 -> (customer3.getCustType().equals("F")) && (customer3.getCountry().equals("USA")))
				.toList();
		System.out.println("Number of customer above 50 years:" + count);
		System.out.println();
		System.out.println("Reqular customer form china and above 18 years");
		Details(regularCustomers);

		System.out.println("Priviledge customer from USA ");
		Details(priviledgedCustomers);

		System.out.println("Requirment 4 and 5");
		for (Customer cust : sortedList) {
			Optional<String> optional = Optional.ofNullable(cust.getEmailId());
			if (optional.isEmpty()) {
				System.out.println(cust.name + "! your email id is empty");
			} else if (cust.getCustType().equals("F")) {
				cust.setCustType("ER-" + cust.getCustType());
				System.out.println("Id: " + cust.id + "\nName" + cust.name + "\nDate of Birth:" + cust.getDob()
						+ "\nCustomer Type:" + cust.getCustType() + "\nGender:" + cust.getGender() + "\nContacts"
						+ cust.getContactNo() + "\nEmail-id" + cust.getEmailId() + "\nRegistration:"
						+ cust.getRegistrationDate() + "\nCountry:" + cust.getContactNo());
				System.out.println("-----------------------");

			}
			ZonedDateTime zone = ZonedDateTime.of(cust.getRegistrationDate(), LocalTime.now(), ZoneId.of(timeZone));
			System.out.println(zone);
			LocalDate date = LocalDate.of(zone.getYear(), zone.getMonth(), zone.getDayOfMonth());
			cust.setRegistrationDate(date);
		}

	}

	public static void Details(List<Customer> customers) {
		for (Customer c : customers) {
			System.out.println("Id" + c.getId() + "\nName:" + c.getName() + "\nDate of Birth:" + c.getDob()
					+ "\nCustomer Type:" + c.getCustType() + "\nGender:" + c.getGender() + "\nContact:"
					+ c.getContactNo() + "\n E-mail:" + c.getEmailId() + "\nRegistration Date:"
					+ c.getRegistrationDate() + "\n Country:" + c.getCountry());
			System.out.println("-----------------------------");
		}
	}
}
