package com.easyrentals.customer;

import java.time.LocalDate;

public class RegularCustomer extends Customer {

	public RegularCustomer(int id, String name, LocalDate dob, String custType, String gender, String contactNo,
			String emailId, LocalDate registrationDate, String country) {
		super(id, name, dob, custType, gender, contactNo, emailId, registrationDate, country);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculateRentalPrice() {
		return 0.0;

	}

}
