package com.infyrail.capstone.service;

import com.infyrail.capstone.dto.RouteDTO;
import com.infyrail.capstone.dto.TrainDTO;
import com.infyrail.capstone.exception.InfyRailException;

public interface RouteService {
	public Integer addRoute(RouteDTO routeDTO) throws InfyRailException;
	public RouteDTO getRoute(Integer routeId) throws InfyRailException;
	public void updateRoute(Integer routeId, String source, String destination) throws InfyRailException;
	public void deleteTrainByRoute(Integer routeId, Integer trainId) throws InfyRailException;
	public void updateTrainByRoute(Integer routeId, TrainDTO trainDTO) throws InfyRailException;
}
