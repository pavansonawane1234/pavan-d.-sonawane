package com.infyrail.capstone.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infyrail.capstone.dto.RouteDTO;
import com.infyrail.capstone.dto.TrainDTO;
import com.infyrail.capstone.exception.InfyRailException;
import com.infyrail.capstone.service.RouteService;
import com.infyrail.capstone.service.TrainService;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/infyRail")
public class InfyRailAPI {

	@Autowired
	private TrainService trainService;

	@Autowired
	private RouteService routeService;

	@Autowired
	private Environment environment;

	@PostMapping(value = "/routes")
	public ResponseEntity<String> addRoute(@Valid @RequestBody RouteDTO route) throws InfyRailException {
		Integer routeId = routeService.addRoute(route);
		String successMessage = environment.getProperty("API.ROUTE_INSERT_SUCCESS") + routeId;
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}

	@GetMapping(value = "routes/{routeId:[0-9]{3}}")
	public ResponseEntity<RouteDTO> getRoute(@PathVariable Integer routeId) throws InfyRailException {
		System.out.println("===============================");
		RouteDTO route = routeService.getRoute(routeId);
		return new ResponseEntity<>(route, HttpStatus.OK);
	}

	@GetMapping(value = "/routes/trains")
	public ResponseEntity<List<TrainDTO>> getTrainBySourceAndDestination(@Valid @RequestParam String source,
			@Valid @RequestParam String destination) throws InfyRailException {
		List<TrainDTO> trainList = trainService.getTrainBySourceAndDestination(source, destination);
		return new ResponseEntity<>(trainList, HttpStatus.OK);
	}

	@PutMapping(value = "/routes/{routeId}")
	public ResponseEntity<String> updateRoute(@Valid @PathVariable Integer routeId,
			@Valid @MatrixVariable(value = "source") String source, @Valid @MatrixVariable(value = "destination") String destination)
			throws InfyRailException {
		System.out.println("route-update");
		routeService.updateRoute(routeId, source, destination);
		String successMessage = environment.getProperty("API.ROUTE_UPDATE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	@DeleteMapping(value = "/routes/{routeId}/{trainId}")
	public ResponseEntity<String> deleteTrainByRoute(@PathVariable Integer routeId, @PathVariable Integer trainId)
			throws InfyRailException {
		routeService.deleteTrainByRoute(routeId, trainId);

		String successMessage = environment.getProperty("API.ROUTE_DELETE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	@PutMapping(value = "/routes/train/{routeId}")
	public ResponseEntity<String> updateTrainByRoute(@PathVariable Integer routeId, @Valid @RequestBody TrainDTO trainDTO)
			throws InfyRailException {
		System.out.println("train-update");
		routeService.updateTrainByRoute(routeId, trainDTO);
		String successMessage = environment.getProperty("API.TRAIN_UPDATE_BY_ROUTE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	@PostMapping(value = "/trains")
	public ResponseEntity<String> addRoute(@Valid @RequestBody TrainDTO train) throws InfyRailException {
		Integer routeId = trainService.addTrain(train);
		String successMessage = environment.getProperty("API.TRAIN_INSERT_SUCCESS") + routeId;
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}

	@PutMapping(value = "/trains/{trainId}")
	public ResponseEntity<String> updateFare(@PathVariable Integer trainId, @Valid @RequestBody TrainDTO train)
			throws InfyRailException {
		trainService.updateFare(trainId, train.getFare());
		String successMessage = environment.getProperty("API.TRAIN_UPDATE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}
}
