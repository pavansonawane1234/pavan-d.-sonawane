package com.infyrail.capstone.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infyrail.capstone.dto.TrainDTO;
import com.infyrail.capstone.entity.Train;
import com.infyrail.capstone.exception.InfyRailException;
import com.infyrail.capstone.repository.TrainRepository;

@Service(value = "trainService")
@Transactional
public class TrainServiceImpl implements TrainService {
	
	@Autowired
	private TrainRepository trainRepository;
	
	public List<TrainDTO> getTrainBySourceAndDestination(String source, String destination) throws InfyRailException {
		List<Train> t1 = trainRepository.getTrainBySourceDestination(source, destination);
		List<TrainDTO> trainList = new ArrayList<>();
		t1.forEach(t -> {
		TrainDTO train = new TrainDTO();
		train.setId(t.getId());
		train.setTrainName(t.getTrainName());
		train.setDepartureTime(t.getDepartureTime());
		train.setArrivalTime(t.getArrivalTime());
		train.setFare(t.getFare());
		trainList.add(train);
		});

		if(trainList.isEmpty()) {
			throw new InfyRailException("Service.TRAIN_NOT_FOUND_BY_SOURCE_DESTINATION");
		}
		return trainList;
	}
	
	@Override
	public Integer addTrain(TrainDTO trainDTO) throws InfyRailException {
		Train t = new Train();
		t.setArrivalTime(trainDTO.getArrivalTime());
		t.setDepartureTime(trainDTO.getDepartureTime());
		t.setFare(trainDTO.getFare());
		t.setTrainName(trainDTO.getTrainName());
		Train t1 = trainRepository.save(t);
		return t1.getId();
	}
	
	@Override
	public void updateFare(Integer trainId, Double fare) throws InfyRailException {
		System.out.println("update");
		Optional<Train> train = trainRepository.findById(trainId);
		Train t = train.orElseThrow(() -> new InfyRailException("Service.TRAIN_NOT_FOUND"));
		t.setFare(fare);
	}
}
