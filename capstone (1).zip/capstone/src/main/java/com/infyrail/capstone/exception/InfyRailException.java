package com.infyrail.capstone.exception;

public class InfyRailException extends Exception {

	private static final long serialVersionUID = 1L;

	public InfyRailException(String message) {
		super(message);	
	}
}
