package com.infyrail.capstone.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infyrail.capstone.entity.Route;
import com.infyrail.capstone.exception.InfyRailException;

@Transactional
@Repository
public interface RouteRepository extends CrudRepository<Route, Integer>{
	
	public List<Route> findBySourceAndDestination(String source, String destination) throws InfyRailException;
	
	@Modifying
	@Query(value= "update route set train_id = null where id = :routeId and train_id= :trainId", nativeQuery= true)
	public void deleteTrainByRoute(Integer routeId, Integer trainId);
}
