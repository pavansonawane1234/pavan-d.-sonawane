package com.infyrail.capstone.service;

import java.util.List;

import com.infyrail.capstone.dto.TrainDTO;
import com.infyrail.capstone.exception.InfyRailException;

public interface TrainService {
	
	public List<TrainDTO> getTrainBySourceAndDestination(String source, String destination) throws InfyRailException;
	public Integer addTrain(TrainDTO trainDTO) throws InfyRailException;
	public void updateFare(Integer trainId, Double fare) throws InfyRailException;
}
