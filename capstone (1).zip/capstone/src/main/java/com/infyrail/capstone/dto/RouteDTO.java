package com.infyrail.capstone.dto;

import jakarta.validation.constraints.Pattern;
import com.infyrail.capstone.entity.Train;
import jakarta.validation.constraints.NotNull;

public class RouteDTO {
	
	Integer id;
	@NotNull(message="Please enter your source")
	@Pattern(regexp="[A-Za-z]+",message="Source should contain only alphabets")
	String source;
	@NotNull(message="Please enter your destination")
	@Pattern(regexp="[A-Za-z]+",message="Destination should contain only alphabets")
	String destination;
	@NotNull(message="Train must not be empty")
	Train trainList;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Train getTrainList() {
		return trainList;
	}
	public void setTrainList(Train trainList) {
		this.trainList = trainList;
	}
	@Override
	public String toString() {
		return "RouteDTO [id=" + id + ", source=" + source + ", destination=" + destination + ", trainList=" + trainList
				+ "]";
	}
	
}
