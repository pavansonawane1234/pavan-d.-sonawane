package com.infyrail.capstone.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infyrail.capstone.entity.Train;
import com.infyrail.capstone.exception.InfyRailException;

@Transactional
@Repository
public interface TrainRepository extends CrudRepository<Train, Integer> {

	@Query(value="SELECT t.* FROM train t, route r "
	+ "where r.source= :source "
	+ "and r.destination= :destination "
	+ "and r.train_id= t.id", nativeQuery=true)
	public List<Train> getTrainBySourceDestination(String source, String destination) throws InfyRailException;
}
