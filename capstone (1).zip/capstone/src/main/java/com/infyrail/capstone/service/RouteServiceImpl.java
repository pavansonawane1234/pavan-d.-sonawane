package com.infyrail.capstone.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infyrail.capstone.dto.RouteDTO;
import com.infyrail.capstone.dto.TrainDTO;
import com.infyrail.capstone.entity.Route;
import com.infyrail.capstone.entity.Train;
import com.infyrail.capstone.exception.InfyRailException;
import com.infyrail.capstone.repository.RouteRepository;
import com.infyrail.capstone.repository.TrainRepository;

@Service(value = "routeService")
@Transactional
public class RouteServiceImpl implements RouteService{

	@Autowired
	private RouteRepository routeRepository;
	
	@Autowired
	private TrainRepository trainRepository;
	
	@Override
	public Integer addRoute(RouteDTO routeDTO) throws InfyRailException{
		Route route = new Route();
		route.setSource(routeDTO.getSource());
		route.setDestination(routeDTO.getDestination());
		Train t = new Train();
		if(routeDTO.getTrainList().getArrivalTime() == null) {
			throw new InfyRailException("Service.ARRIVAL_TIME_ERROR");
		}
		if(routeDTO.getTrainList().getDepartureTime() == null) {
			throw new InfyRailException("Service.DEPARTURE_TIME_ERROR");
		}
		if(routeDTO.getTrainList().getTrainName() == null) {
			throw new InfyRailException("Service.TRAIN_NAME_ERROR");
		}
		if(routeDTO.getTrainList().getFare() == null) {
			throw new InfyRailException("Service.TRAIN_FARE_ERROR");
		}
		t.setArrivalTime(routeDTO.getTrainList().getArrivalTime());
		t.setDepartureTime(routeDTO.getTrainList().getDepartureTime());
		t.setFare(routeDTO.getTrainList().getFare());
		t.setTrainName(routeDTO.getTrainList().getTrainName());
		route.setTrainList(t);
		Route route2 = routeRepository.save(route);
		return route2.getId();
	}

	@Override
	public RouteDTO getRoute(Integer routeId) throws InfyRailException {
		Optional<Route> op = routeRepository.findById(routeId); 
		Route route = op.orElseThrow(() -> new InfyRailException("Service.ROUTE_NOT_FOUND"));
		RouteDTO route2 = new RouteDTO();
		route2.setId(route.getId());
		route2.setSource(route.getSource());
		route2.setDestination(route.getDestination());
		route2.setTrainList(route.getTrainList());
		return route2;
	}

	@Override
	public void updateRoute(Integer routeId, String source, String destination) throws InfyRailException {
		Optional<Route> o = routeRepository.findById(routeId);
		Route route = o.orElseThrow(()-> new InfyRailException("Service.ROUTE_NOT_FOUND"));
		if(source != null && !source.isEmpty()) {
		route.setSource(source);
		}
		if(destination != null && !destination.isEmpty()) {
		route.setDestination(destination);
		}
		routeRepository.save(route);
	}

	@Override
	public void deleteTrainByRoute(Integer routeId, Integer trainId) throws InfyRailException {
		Optional<Route> op = routeRepository.findById(routeId);
		Route route = op.orElseThrow(() -> new InfyRailException("Service.ROUTE_NOT_FOUND"));
		
		Optional<Train> op1 = trainRepository.findById(route.getTrainList().getId());
		@SuppressWarnings("unused")
		Train train = op1.orElseThrow(() -> new InfyRailException("Service.TRAIN_NOT_FOUND"));
		
		routeRepository.deleteTrainByRoute(routeId, trainId);
		
		//route.setTrainList(null);
		//routeRepository.save(route);
		
	}

	@Override
	public void updateTrainByRoute(Integer routeId, TrainDTO trainDTO) throws InfyRailException {
		Optional<Route> op = routeRepository.findById(routeId);
		Route route = op.orElseThrow(() -> new InfyRailException("Service.ROUTE_NOT_FOUND"));
		
		Optional<Train> op1 = trainRepository.findById(route.getTrainList().getId());
		Train train = op1.orElseThrow(() -> new InfyRailException("Service.TRAIN_NOT_FOUND"));
		if(trainDTO.getArrivalTime() != null) {
			train.setArrivalTime(trainDTO.getArrivalTime());
		}
		if(trainDTO.getDepartureTime() != null) {
			train.setDepartureTime(trainDTO.getDepartureTime());
		}
		if(trainDTO.getTrainName() != null) {
			train.setTrainName(trainDTO.getTrainName());
		}
		if(trainDTO.getFare() != null) {
			train.setFare(trainDTO.getFare());
		}
		trainRepository.save(train);
	}
}
